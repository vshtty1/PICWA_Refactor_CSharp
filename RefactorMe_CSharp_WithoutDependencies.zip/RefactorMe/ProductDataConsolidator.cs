﻿using RefactorMe.DontRefactor.Data.Implementation;
using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RefactorMe.Constants;
using RefactorMe.Interface;
using RefactorMe.Utilities;

namespace RefactorMe
{
    public class ProductDataConsolidator : IProductDataConsolidator
    {       
        public List<Product> GetAllByCurrency(double currency)
        {
            var prodAll = Helper.GetAll(currency);
            return prodAll;
        }
    }
}

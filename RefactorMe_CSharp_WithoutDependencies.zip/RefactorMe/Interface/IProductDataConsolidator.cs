﻿using RefactorMe.DontRefactor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe.Interface
{
    internal interface IProductDataConsolidator
    {
        List<Product> GetAllByCurrency(double currency);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefactorMe.DontRefactor.Models
{
    public class TShirt : Product
    {
        public string Colour { get; set; }

        public string ShirtText { get; set; }
    }
}

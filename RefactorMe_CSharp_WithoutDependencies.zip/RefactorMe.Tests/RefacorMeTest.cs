﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using Xunit;
using RefactorMe;
using RefactorMe.Constants;
using System.Linq;

namespace RefactorMe.Test
{
    public class RefacorMeTest
    {
        [Fact]
        public void HasConsolidatedProducts()
        {
            //Arrange
            var consolidator = new ProductDataConsolidator();

            //Act
            var productList = consolidator.GetAllByCurrency(CurrencyRate.Default);

            //Assert
            Xunit.Assert.True(productList!=null && productList.Count()>0);
        }
        [Fact]
        public void ISCurrencyConversionApplied()
        {
            //Arrange
            var consolidator = new ProductDataConsolidator();

            //Act
            var priceList = consolidator.GetAllByCurrency(CurrencyRate.Default).Select(x => x.Price).Sum();
            var priceListUSD = consolidator.GetAllByCurrency(CurrencyRate.USDollar).Select(x => x.Price).Sum();
            var priceListEUR = consolidator.GetAllByCurrency(CurrencyRate.Euro).Select(x => x.Price).Sum();


            //Assert
            Xunit.Assert.True((Math.Round(priceList * CurrencyRate.USDollar) == Math.Round(priceListUSD)) 
                && (Math.Round(priceList * CurrencyRate.Euro)==Math.Round(priceListEUR)));
        }
        [Fact]
        public void HasLawnMowerProducts()
        {
            //Arrange
            var consolidator = new ProductDataConsolidator();

            //Act
            var productList = consolidator.GetAllByCurrency(CurrencyRate.USDollar);

            //Assert
            Xunit.Assert.Contains(productList, x => x.Type == "Lawnmower");
        }        
        [Fact]
        public void HasPhoneCaseProducts()
        {
            //Arrange
            var consolidator = new ProductDataConsolidator();

            //Act
            var productList = consolidator.GetAllByCurrency(CurrencyRate.USDollar);

            //Assert
            Xunit.Assert.Contains(productList, x => x.Type == "PhoneCase");
        }
        [Fact]
        public void HasTShirtProducts()
        {
            //Arrange
            var consolidator = new ProductDataConsolidator();

            //Act
            var productList = consolidator.GetAllByCurrency(CurrencyRate.USDollar);

            //Assert
            Xunit.Assert.Contains(productList, x => x.Type == "TShirt");
        }
    }
}
